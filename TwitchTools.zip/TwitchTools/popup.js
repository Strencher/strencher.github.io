window.$ = function (r) {return document.querySelectorAll(r)}
$("#btn")[0].addEventListener("click", e=> {
    if(!$("#input")[0].value) return;
    open(`https://www.twitch.tv/popout/ShoXx__/viewercard/${$("#input")[0].value}`);
    localStorage.setItem("last", $("#input")[0].value)
})
$("#input")[0].addEventListener("keydown", e=> {
    if(e.key == "Enter") {
        $("#btn")[0].click()
    }
})
window.addEventListener("keydown", e=> {
    if(e.ctrlKey && e.key == "d") {
        $("#input")[0].value = (() => {
            if(!localStorage.getItem("last")) return "hi";
            else return localStorage.getItem("last");
        })();
    }
})