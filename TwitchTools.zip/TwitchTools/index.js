if(location.href.includes("twitch")) {
function parseDOM(e) {
    var a = document.createElement("div");
    a.innerHTML = e;
    return a.childNodes[0];
}

this.observer = new MutationObserver(changes => {
    changes.forEach(e=> {
        e.addedNodes.forEach(r => {
            if(r && r.classList && r.classList.contains("simplebar-scroll-content")) {
                r.querySelectorAll('h4.tw-word-break-word').forEach(el => {
                    if(el) {
                        el.append(parseDOM(`<img width="17" height="17" class="CopyIcon" style="cursor: pointer; filter: invert(70%)" src="https://image.flaticon.com/icons/svg/1621/1621635.svg">`))
                        el.querySelector(".CopyIcon").onclick = async function () {
                            await navigator.clipboard.writeText("!tokens add "+el.innerText+" 5000000")
                        }
                    }
                })
            }
            if(r && r.classList && r.tagName == "H4" && r.classList.contains("tw-word-break-word")) {
                r.append(parseDOM(`<img width="17" height="17" class="CopyIcon" style="cursor: pointer; filter: invert(70%)" src="https://image.flaticon.com/icons/svg/1621/1621635.svg">`))
                r.querySelector(".CopyIcon").onclick = async function () {
                    await navigator.clipboard.writeText("!tokens add "+r.innerText+" 5000000")
                }
            }
            if(r && r.classList && r.classList.contains("tw-align-items-center")) {
                r.querySelectorAll("h4.tw-word-break-word").forEach(o => {
                    if(o) {
                        o.append(parseDOM(`<img width="17" height="17" class="CopyIcon" style="cursor: pointer; filter: invert(70%)" src="https://image.flaticon.com/icons/svg/1621/1621635.svg">`))
                        document.querySelector(".CopyIcon").onclick = async function () {
                            await navigator.clipboard.writeText("!tokens add "+o.innerText+" 5000000")
                        }
                    }
                })
            }
        })
    })
})
this.observer.observe(document.body, {childList: true, subtree: true})
}