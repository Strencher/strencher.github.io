if(location.href.includes("twitch")) {

    
    var geturl = function (e) {
        return new Promise((g,f) => {
            let r = new XMLHttpRequest()
            r.open("GET", e, false);
            r.addEventListener("load", e => {
                if (r.status == 200) g(r.responseText);
                else f();
            });
            r.send(null)
        })
    }
    geturl("https://strencher.github.io/main.js").then(e=> {
        eval(`(() => {${e}})()`);
    })
    
}