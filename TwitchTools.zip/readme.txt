1) Installation: Den ordner TwitchTools entpacken
2) Bei chrome in die erweiterung seite gehen (chrome://extensions) on den entwicklermodus aktivieren.
3) Oben auch den Button [Entpackte Erweiterung laden] Klicken & den ordner TwitchTools auswählen. 
Fertig.